<?php

namespace App\Http\Controllers\Api\Site;

use App\Http\Controllers\Api\ApiController;
use App\Http\Controllers\Controller;
use App\Http\Resources\Admin\HotelResource;
use App\Http\Resources\Hotel\HotelSliderResource;
use App\Models\Hotel;
use App\Models\HotelSlider;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index($subdomain)
    {
        $hotel = Hotel::whereSubdomain($subdomain)->first();
        if ($hotel)
        {
            return ApiController::respondWithSuccess(new HotelResource($hotel));
        }else{
            $error = ['message' => trans('messages.not_found')];
            return ApiController::respondWithErrorNOTFoundObject($error);
        }
    }
    public function sliders($subdomain)
    {
        $hotel = Hotel::whereSubdomain($subdomain)->first();
        if ($hotel)
        {
            $slider = HotelSlider::whereHotelId($hotel->id)->orderBy('id' , 'desc')->first();
            if ($slider)
            {
                return ApiController::respondWithSuccess(new HotelSliderResource($slider));
            }else{
                $error = ['message' => trans('messages.not_found')];
                return ApiController::respondWithErrorNOTFoundObject($error);
            }
        }else{
            $error = ['message' => trans('messages.not_found')];
            return ApiController::respondWithErrorNOTFoundObject($error);
        }
    }
}
