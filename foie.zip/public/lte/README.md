Introduction
============
**Translate from ltr to RTL**

**AdminLTE** is a fully responsive administration template. Based on **[Bootstrap 4](https://getbootstrap.com)** framework. 

**Download & Preview on [AdminLTE.io](https://adminlte.io)**

!["AdminLTE"](/image.png)

